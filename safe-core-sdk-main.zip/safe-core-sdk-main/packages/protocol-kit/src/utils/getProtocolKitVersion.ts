export const getProtocolKitVersion = () => '6.0.4'
