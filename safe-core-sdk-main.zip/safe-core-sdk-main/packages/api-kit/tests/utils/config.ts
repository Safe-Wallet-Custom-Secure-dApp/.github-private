const config = {
  CHAIN_ID: 11155111n,
  JSON_RPC: 'https://sepolia.gateway.tenderly.co',
  EIP_3770_PREFIX: 'sep'
}

export default config
