import { EMPTY_DATA } from './constants'

export const isEmptyData = (input: string) => !input || input === EMPTY_DATA
