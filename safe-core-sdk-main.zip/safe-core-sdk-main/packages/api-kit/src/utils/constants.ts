export const EMPTY_DATA = '0x'
