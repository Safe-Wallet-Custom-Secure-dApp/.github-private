export const getRelayKitVersion = () => '4.0.3'
